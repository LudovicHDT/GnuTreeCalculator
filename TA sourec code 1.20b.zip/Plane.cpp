#include "stdafx.h"
#include ".\plane.h"

CPlane::CPlane(void)
{
	d=0;
	this->PutXyz(0,0,0);
}

CPlane::~CPlane(void)
{
}
